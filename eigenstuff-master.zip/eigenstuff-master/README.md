Scrape search queries from Google. The code quality isn't the best (should factor out the configuration into a static file at some point!)

You probably need to run it through a proxy: `$ HTTP_PROXY=xyz python analyze.py`

![lang](https://raw.githubusercontent.com/erikbern/eigenstuff/master/prog_lang_matrix.png)

![lang](https://raw.githubusercontent.com/erikbern/eigenstuff/master/prog_lang_matrix_eig.png)
